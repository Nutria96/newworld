﻿const CACHE_NAME = 'chongoku-sebs-v1';
const urlsToCache = ['/', '/clasico.html', '/viaje.html', '/manifest.json'];
self.addEventListener('install', event => { event.waitUntil(caches.open(CACHE_NAME).then(cache => { console.log('✅ Cache abierta'); return cache.addAll(urlsToCache); }).catch(err => console.log('❌ Error al cachear:', err))); });
self.addEventListener('activate', event => { const cacheWhitelist = [CACHE_NAME]; event.waitUntil(caches.keys().then(cacheNames => { return Promise.all(cacheNames.map(cacheName => { if (!cacheWhitelist.includes(cacheName)) { console.log('🗑️ Eliminando caché vieja:', cacheName); return caches.delete(cacheName); } })); })); });
self.addEventListener('fetch', event => { event.respondWith(caches.match(event.request).then(response => response || fetch(event.request)).catch(() => new Response('Offline', { status: 503, statusText: 'Service Unavailable' }))); });
