﻿# Chongoku Sebs Corp — Chat Limpio

- Los mensajes del usuario se desvanecen después de 6 segundos.
- Las respuestas de la IA se mantienen hasta el siguiente mensaje.
- El chat no se satura, siempre limpio.

🌿 La cura divina está en la tierra. No la criminalicen.
