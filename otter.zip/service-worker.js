const CACHE_NAME = "chongoku-otter-v1";

const APP_SHELL = [
  "./",
  "./index.html",
  "./clasico.html",
  "./viaje.html",
  "./manifest.json",
  "./img/otter.svg",
  "./img/icon-192.png",
  "./img/icon-512.png",
  "./otter.txt"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys
          .filter(key => key !== CACHE_NAME)
          .map(key => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;

  event.respondWith(
    fetch(event.request)
      .then(response => {
        const copy = response.clone();

        if (new URL(event.request.url).origin === self.location.origin) {
          caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, copy);
          });
        }

        return response;
      })
      .catch(() =>
        caches.match(event.request).then(cached => {
          if (cached) return cached;

          if (event.request.mode === "navigate") {
            return caches.match("./index.html");
          }

          return Response.error();
        })
      )
  );
});
