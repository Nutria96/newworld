# Chongoku Sebs Corp — Smart World AI

Paquete estático preparado para:

- Repositorio: `https://github.com/Nutria96/newworld`
- Dominio: `sebchongcorp.com`
- Hosting: Netlify
- Build: **sin Hugo y sin compilación**

## Archivos

- `index.html`: menú principal.
- `clasico.html`: partículas y modo NITRO.
- `viaje.html`: carritos espaciales y salto interestelar.
- `manifest.json`: instalación PWA.
- `service-worker.js`: caché offline.
- `netlify.toml`: configuración de Netlify.
- `img/`: iconos de nutria.
- `otter.txt`: frase motivacional.

## Subir a GitHub

1. Descomprime `otter.zip`.
2. Abre el repositorio `Nutria96/newworld`.
3. Sube **el contenido descomprimido**, no el ZIP.
4. Reemplaza los archivos anteriores cuando GitHub lo solicite.
5. Confirma el commit en la rama conectada con Netlify.

## Configurar Netlify

En **Site configuration → Build & deploy** verifica:

- Production branch: `main`
- Base directory: vacío
- Build command: `echo 'No build needed'`
- Publish directory: `.`
- Functions directory: vacío

El archivo `netlify.toml` ya contiene:

```toml
[build]
  command = "echo 'No build needed'"
  publish = "."
```

No selecciones Hugo, Next.js, Vite ni otro framework.

## Dominio sebchongcorp.com

En **Domain management**:

1. Agrega `sebchongcorp.com`.
2. Agrega también `www.sebchongcorp.com` si deseas usar `www`.
3. Sigue los registros DNS que muestre Netlify.
4. Activa HTTPS cuando Netlify confirme el dominio.

## Cuando el deploy falle

Revisa:

- Que `index.html` esté en la raíz.
- Que Netlify publique `.`.
- Que la rama correcta sea `main`.
- Que no exista una configuración antigua de Hugo.
- Que no haya un `base` incorrecto configurado en Netlify.
- Que los nombres respeten mayúsculas y minúsculas.

## Probar localmente

Puedes abrir `index.html` directamente. Para probar correctamente el service worker usa un servidor local:

```powershell
python -m http.server 8080
```

Después abre:

```text
http://localhost:8080
```
