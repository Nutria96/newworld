# MEDICINE — CHONGOKU SMART WORLD AI

Paquete final con:

- Página espacial y chat temporal.
- Banco de respuestas offline.
- Aprendizaje mediante correcciones.
- Ollama opcional con `llama3`.
- `respuestas.json` actualizado automáticamente.
- Registro en `preguntas.txt`, `respuestas.txt` e `interacciones.jsonl`.
- Resumen semanal.
- PWA y funcionamiento offline.
- Sección de apoyo para medicinas.
- Tarea programada de Windows y GitHub Actions cada 6 horas.

## Uso rápido en Netlify

1. Descomprime `medicine.zip`.
2. Sube **todo el contenido** a la raíz de tu repositorio.
3. Haz commit en la rama conectada con Netlify.
4. Netlify publicará `index.html` automáticamente.

En Netlify estático, el chat usa `respuestas.json` y aprendizaje local del navegador.

## Cerebro completo en tu computadora

Requisitos:

- Windows 10/11.
- Python 3.10 o superior.
- Ollama es opcional.

Ejecuta:

```powershell
python cerebro_temporal.py --serve
```

Abre:

```text
http://127.0.0.1:8765
```

## Ollama opcional

Instala Ollama y descarga el modelo:

```powershell
ollama pull llama3
```

Después inicia el sitio con:

```powershell
python cerebro_temporal.py --serve
```

Si Ollama no responde, el sistema usa el banco offline.

## Modo manual

```powershell
python cerebro_temporal.py --manual "¿Qué es Chongoku Sebs Corp?"
```

## Actualización única

```powershell
python cerebro_temporal.py --refresh
```

## Actualización permanente cada 6 horas

```powershell
python cerebro_temporal.py --daemon
```

## Programador de tareas de Windows

Abre PowerShell en la carpeta y ejecuta:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\INSTALAR_TAREA_WINDOWS.ps1
```

## GitHub Actions

El archivo `.github/workflows/actualizar-respuestas.yml` ejecuta una actualización cada 6 horas y publica los cambios.

GitHub puede solicitar que habilites permisos de escritura para Actions:

- Settings
- Actions
- General
- Workflow permissions
- Read and write permissions

## Donaciones

La información pública está en `donaciones.json`.

Datos incluidos:

- PayPal: `nutria9999`
- BBVA CLABE: `012813015799558334`
- BBVA cuenta: `1579955833`

No se incluyó un número de tarjeta porque no se proporcionó uno de 16 dígitos.

Antes de publicar, conviene agregar el nombre real del beneficiario en `donaciones.json` para que los donantes puedan confirmar la transferencia.

## Seguridad

- Nunca publiques NIP, contraseña, CVV ni códigos SMS.
- Los datos de `donaciones.json` serán públicos en GitHub y Netlify.
- El backend local escucha solamente en `127.0.0.1`.
- Las correcciones del sitio estático se guardan en el navegador del visitante.
- El aprendizaje compartido requiere ejecutar el servidor Python o conectar una base de datos externa.
