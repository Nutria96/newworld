#requires -Version 5.1
$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Script = Join-Path $Root "cerebro_temporal.py"
$Python = (Get-Command python -ErrorAction Stop).Source
$TaskName = "Chongoku-Cerebro-Temporal-6H"

$Action = "`"$Python`" `"$Script`" --refresh"
schtasks.exe /Create /TN $TaskName /SC HOURLY /MO 6 /TR $Action /F | Out-Host

Write-Host ""
Write-Host "Tarea instalada: $TaskName" -ForegroundColor Green
Write-Host "Se ejecutará cada 6 horas." -ForegroundColor Cyan
