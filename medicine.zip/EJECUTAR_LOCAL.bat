@echo off
cd /d "%~dp0"
python cerebro_temporal.py --serve
pause
