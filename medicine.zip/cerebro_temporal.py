#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CEREBRO TEMPORAL CHONGOKU
=========================

Servidor local y generador automático de respuestas para:
Chongoku Sebs Corp - Smart World AI.

Funciones:
- Banco de respuestas offline.
- Ollama opcional con llama3 o mistral.
- API local /api/chat y /api/feedback.
- Historial y aprendizaje por correcciones.
- Regeneración de respuestas.json.
- Resumen semanal.
- Modo manual, servidor y actualización automática.
- Publicación Git opcional.

No requiere librerías externas.
"""

from __future__ import annotations

import argparse
import collections
import datetime as dt
import difflib
import hashlib
import http.server
import json
import os
import re
import subprocess
import sys
import threading
import time
import unicodedata
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config.json"
BANK_PATH = ROOT / "banco_respuestas.json"
KNOWLEDGE_PATH = ROOT / "conocimiento.json"
QUESTIONS_PATH = ROOT / "preguntas.txt"
ANSWERS_PATH = ROOT / "respuestas.txt"
INTERACTIONS_PATH = ROOT / "interacciones.jsonl"
FEEDBACK_PATH = ROOT / "feedback.jsonl"
PUBLIC_RESPONSES_PATH = ROOT / "respuestas.json"
DONATIONS_PATH = ROOT / "donaciones.json"
SUMMARY_DIR = ROOT / "resumenes"

FILE_LOCK = threading.RLock()


def utc_now() -> str:
    """Devuelve fecha UTC con zona horaria."""
    return dt.datetime.now(dt.timezone.utc).isoformat()


def load_json(path: Path, default: Any) -> Any:
    """Lee JSON de forma segura."""
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def atomic_write_json(path: Path, data: Any) -> None:
    """Escribe JSON sin dejar archivos parciales."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temporary.replace(path)


def append_text(path: Path, value: str) -> None:
    """Agrega una línea a un archivo UTF-8."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(value.replace("\r", " ").replace("\n", " ").strip() + "\n")


def append_jsonl(path: Path, data: Dict[str, Any]) -> None:
    """Agrega un objeto JSON a un archivo JSONL."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(data, ensure_ascii=False) + "\n")


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    """Carga registros válidos desde JSONL."""
    rows: List[Dict[str, Any]] = []
    if not path.exists():
        return rows

    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if not line.strip():
            continue
        try:
            value = json.loads(line)
            if isinstance(value, dict):
                rows.append(value)
        except json.JSONDecodeError:
            continue
    return rows


def normalize(text: str) -> str:
    """Normaliza una frase para buscar coincidencias."""
    decomposed = unicodedata.normalize("NFD", text.lower())
    without_accents = "".join(
        char for char in decomposed
        if unicodedata.category(char) != "Mn"
    )
    cleaned = re.sub(r"[^a-z0-9\s]", " ", without_accents)
    return re.sub(r"\s+", " ", cleaned).strip()


def detect_language(text: str, default: str = "es") -> str:
    """Detección ligera sin dependencias externas."""
    normalized = f" {normalize(text)} "
    words = {
        "es": [" que ", " como ", " para ", " quiero ", " necesito ", " hola ", " gracias "],
        "en": [" the ", " what ", " how ", " please ", " hello ", " thanks ", " need "],
        "pt": [" voce ", " como ", " para ", " quero ", " preciso ", " ola ", " obrigado "],
        "fr": [" comment ", " pour ", " bonjour ", " merci ", " besoin ", " pouvez "],
    }

    scores = {
        language: sum(1 for word in markers if word in normalized)
        for language, markers in words.items()
    }
    best = max(scores, key=scores.get)
    return best if scores[best] > 0 else default


def fallback_response(language: str) -> str:
    """Respuesta segura cuando no hay modelo ni coincidencia."""
    responses = {
        "es": "🌌 Recibí tu transmisión, comandante. Aún estoy aprendiendo esta ruta, pero podemos dividir tu pregunta en pasos y encontrar juntos una respuesta.",
        "en": "🌌 I received your transmission, commander. I am still learning this route, but we can break your question into steps and find an answer together.",
        "pt": "🌌 Recebi sua transmissão, comandante. Ainda estou aprendendo esta rota, mas podemos dividir a pergunta em etapas e encontrar uma resposta juntos.",
        "fr": "🌌 J’ai reçu votre transmission, commandant. J’apprends encore cette route, mais nous pouvons diviser la question en étapes et chercher une réponse ensemble.",
    }
    return responses.get(language, responses["es"])


def similarity(left: str, right: str) -> float:
    """Compara dos preguntas normalizadas."""
    return difflib.SequenceMatcher(None, normalize(left), normalize(right)).ratio()


def load_knowledge() -> List[Dict[str, Any]]:
    data = load_json(KNOWLEDGE_PATH, [])
    return data if isinstance(data, list) else []


def save_knowledge(rows: List[Dict[str, Any]]) -> None:
    atomic_write_json(KNOWLEDGE_PATH, rows)


def upsert_knowledge(question: str, answer: str, source: str = "feedback") -> None:
    """Guarda o actualiza una respuesta aprendida."""
    normalized_question = normalize(question)
    if not normalized_question or not answer.strip():
        return

    with FILE_LOCK:
        rows = load_knowledge()
        for row in rows:
            if row.get("pregunta_normalizada") == normalized_question:
                row["pregunta"] = question.strip()
                row["respuesta"] = answer.strip()
                row["fuente"] = source
                row["usos"] = int(row.get("usos", 0)) + 1
                row["actualizado"] = utc_now()
                save_knowledge(rows)
                return

        rows.append({
            "pregunta": question.strip(),
            "pregunta_normalizada": normalized_question,
            "respuesta": answer.strip(),
            "fuente": source,
            "usos": 1,
            "actualizado": utc_now(),
        })
        save_knowledge(rows)


def answer_from_knowledge(question: str) -> Optional[str]:
    """Busca una corrección o respuesta aprendida."""
    best_answer: Optional[str] = None
    best_score = 0.0

    for row in load_knowledge():
        saved_question = str(row.get("pregunta", ""))
        score = similarity(question, saved_question)
        if score > best_score:
            best_score = score
            best_answer = str(row.get("respuesta", "")).strip()

    return best_answer if best_score >= 0.88 and best_answer else None


def answer_from_bank(question: str) -> Optional[str]:
    """Busca palabras clave en el banco inicial."""
    normalized_question = normalize(question)
    bank = load_json(BANK_PATH, [])

    for item in bank if isinstance(bank, list) else []:
        for phrase in item.get("preguntas", []):
            normalized_phrase = normalize(str(phrase))
            if normalized_phrase and normalized_phrase in normalized_question:
                return str(item.get("respuesta", "")).strip() or None
    return None


def ask_ollama(question: str, language: str, config: Dict[str, Any]) -> Optional[str]:
    """Consulta Ollama. Devuelve None si no está disponible."""
    ollama = config.get("ollama", {})
    if not ollama.get("activo", True):
        return None

    language_names = {
        "es": "español",
        "en": "English",
        "pt": "português",
        "fr": "français",
    }
    language_name = language_names.get(language, "español")

    prompt = f"""
Eres Chongoku Smart World AI, una IA temporal de una nave perdida.
Responde en {language_name}.
Tono: poético, cósmico, motivador, solidario y claro.
Usa emojis con moderación: 🌌 🚀 💫 🌿.
No inventes que ejecutaste acciones.
No solicites contraseñas, NIP, códigos bancarios ni secretos.
Pregunta del usuario:
{question}
""".strip()

    payload = json.dumps({
        "model": ollama.get("modelo", "llama3"),
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.55,
        },
    }).encode("utf-8")

    request = urllib.request.Request(
        str(ollama.get("url", "http://127.0.0.1:11434/api/generate")),
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(
            request,
            timeout=int(ollama.get("timeout_segundos", 45)),
        ) as response:
            parsed = json.loads(response.read().decode("utf-8"))
            text = str(parsed.get("response", "")).strip()
            return text or None
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError):
        return None


def save_interaction(
    question: str,
    answer: str,
    language: str,
    source: str,
) -> Dict[str, Any]:
    """Registra pregunta y respuesta en todos los archivos solicitados."""
    row = {
        "id": hashlib.sha256(
            f"{utc_now()}|{question}|{answer}".encode("utf-8")
        ).hexdigest()[:20],
        "fecha": utc_now(),
        "pregunta": question.strip(),
        "pregunta_normalizada": normalize(question),
        "respuesta": answer.strip(),
        "idioma": language,
        "fuente": source,
    }

    with FILE_LOCK:
        append_text(QUESTIONS_PATH, question)
        append_text(ANSWERS_PATH, answer)
        append_jsonl(INTERACTIONS_PATH, row)

    return row


def answer_question(question: str) -> Dict[str, Any]:
    """Motor principal de respuestas."""
    config = load_json(CONFIG_PATH, {})
    default_language = str(config.get("idioma_predeterminado", "es"))
    language = detect_language(question, default_language)

    answer = answer_from_knowledge(question)
    source = "conocimiento"

    if not answer:
        answer = answer_from_bank(question)
        source = "banco"

    if not answer:
        answer = ask_ollama(question, language, config)
        source = "ollama"

    if not answer:
        answer = fallback_response(language)
        source = "offline"

    interaction = save_interaction(question, answer, language, source)

    return {
        "ok": True,
        "answer": answer,
        "language": language,
        "source": source,
        "interaction_id": interaction["id"],
    }


def save_feedback(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Guarda valoración y corrección del usuario."""
    question = str(payload.get("question", "")).strip()
    original_answer = str(payload.get("answer", "")).strip()
    corrected_answer = str(payload.get("corrected_answer", "")).strip()
    rating = str(payload.get("rating", "")).strip()

    if not question:
        return {"ok": False, "error": "Falta la pregunta."}

    row = {
        "fecha": utc_now(),
        "pregunta": question,
        "respuesta_original": original_answer,
        "respuesta_corregida": corrected_answer,
        "valoracion": rating,
    }

    with FILE_LOCK:
        append_jsonl(FEEDBACK_PATH, row)

    if corrected_answer:
        upsert_knowledge(question, corrected_answer, "correccion_usuario")

    return {"ok": True, "learned": bool(corrected_answer)}


def latest_answer_by_question(
    interactions: Iterable[Dict[str, Any]]
) -> Dict[str, Dict[str, Any]]:
    """Conserva la respuesta más reciente por pregunta normalizada."""
    result: Dict[str, Dict[str, Any]] = {}
    for row in interactions:
        key = str(row.get("pregunta_normalizada", "")).strip()
        if key:
            result[key] = row
    return result


def create_weekly_summary(interactions: List[Dict[str, Any]]) -> Optional[Path]:
    """Genera un resumen semanal Markdown."""
    SUMMARY_DIR.mkdir(parents=True, exist_ok=True)
    week_key = dt.datetime.now().strftime("%Y-W%W")
    destination = SUMMARY_DIR / f"resumen_{week_key}.md"

    if destination.exists():
        return None

    normalized_questions = [
        str(row.get("pregunta_normalizada", "")).strip()
        for row in interactions
        if str(row.get("pregunta_normalizada", "")).strip()
    ]
    counts = collections.Counter(normalized_questions)
    latest = latest_answer_by_question(interactions)

    lines = [
        "# Resumen semanal del cerebro temporal",
        "",
        f"Generado: {utc_now()}",
        f"Interacciones analizadas: {len(interactions)}",
        "",
        "## Preguntas más frecuentes",
        "",
    ]

    for question_key, count in counts.most_common(15):
        row = latest.get(question_key, {})
        lines.append(
            f"- **{row.get('pregunta', question_key)}** — {count} veces"
        )

    if not counts:
        lines.append("- Aún no hay suficientes interacciones.")

    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return destination


def refresh_responses() -> Dict[str, Any]:
    """Regenera respuestas.json y fortalece conocimiento frecuente."""
    bank = load_json(BANK_PATH, [])
    interactions = load_jsonl(INTERACTIONS_PATH)
    feedback = load_jsonl(FEEDBACK_PATH)

    corrections = {
        normalize(str(row.get("pregunta", ""))): str(
            row.get("respuesta_corregida", "")
        ).strip()
        for row in feedback
        if str(row.get("respuesta_corregida", "")).strip()
    }

    counts = collections.Counter(
        str(row.get("pregunta_normalizada", "")).strip()
        for row in interactions
        if str(row.get("pregunta_normalizada", "")).strip()
    )
    latest = latest_answer_by_question(interactions)

    frequent: List[Dict[str, Any]] = []
    for key, count in counts.most_common(30):
        row = latest.get(key, {})
        answer = corrections.get(key) or str(row.get("respuesta", "")).strip()
        if not answer:
            continue

        item = {
            "pregunta": row.get("pregunta", key),
            "pregunta_normalizada": key,
            "respuesta": answer,
            "frecuencia": count,
            "actualizado": row.get("fecha", utc_now()),
        }
        frequent.append(item)

        if count >= 2:
            upsert_knowledge(
                str(item["pregunta"]),
                str(item["respuesta"]),
                "analisis_frecuencia",
            )

    output = {
        "version": 1,
        "actualizado": utc_now(),
        "modo": "cerebro_temporal",
        "banco": bank,
        "frecuentes": frequent,
        "total_interacciones": len(interactions),
        "mensaje": "🌌 Respuestas temporales de Chongoku Smart World AI.",
    }

    with FILE_LOCK:
        atomic_write_json(PUBLIC_RESPONSES_PATH, output)

    create_weekly_summary(interactions)
    maybe_publish_git()
    return output


def maybe_publish_git() -> None:
    """Publica cambios si se habilitó explícitamente en config.json."""
    config = load_json(CONFIG_PATH, {})
    publication = config.get("publicacion_git", {})
    if not publication.get("activa", False):
        return

    try:
        subprocess.run(
            ["git", "add", "respuestas.json", "conocimiento.json", "resumenes"],
            cwd=ROOT,
            check=True,
            capture_output=True,
            text=True,
        )

        status = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=ROOT,
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()

        if not status:
            return

        message = str(
            publication.get(
                "mensaje",
                "Actualización automática del cerebro temporal",
            )
        )
        subprocess.run(
            ["git", "commit", "-m", f"{message} - {utc_now()}"],
            cwd=ROOT,
            check=True,
        )
        subprocess.run(
            [
                "git",
                "push",
                "origin",
                str(publication.get("rama", "main")),
            ],
            cwd=ROOT,
            check=True,
        )
    except (OSError, subprocess.CalledProcessError) as error:
        print(f"[AVISO] No se pudo publicar por Git: {error}", file=sys.stderr)


class ChongokuHandler(http.server.SimpleHTTPRequestHandler):
    """Servidor web local y API del cerebro temporal."""

    server_version = "ChongokuTemporal/1.0"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def send_json(self, data: Dict[str, Any], status: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self) -> Dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0 or length > 100_000:
            return {}
        raw = self.rfile.read(length)
        try:
            parsed = json.loads(raw.decode("utf-8"))
            return parsed if isinstance(parsed, dict) else {}
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {}

    def do_GET(self) -> None:
        if self.path == "/api/health":
            self.send_json({
                "ok": True,
                "service": "Chongoku Temporal Brain",
                "time": utc_now(),
            })
            return

        if self.path == "/api/responses":
            self.send_json(load_json(PUBLIC_RESPONSES_PATH, {}))
            return

        if self.path == "/api/donations":
            self.send_json(load_json(DONATIONS_PATH, {}))
            return

        if self.path == "/":
            self.path = "/index.html"

        super().do_GET()

    def do_POST(self) -> None:
        payload = self.read_json()

        if self.path == "/api/chat":
            question = str(payload.get("question", "")).strip()
            if not question:
                self.send_json(
                    {"ok": False, "error": "La pregunta está vacía."},
                    400,
                )
                return

            self.send_json(answer_question(question))
            return

        if self.path == "/api/feedback":
            result = save_feedback(payload)
            self.send_json(result, 200 if result.get("ok") else 400)
            return

        self.send_json({"ok": False, "error": "Ruta no encontrada."}, 404)

    def log_message(self, format_string: str, *args: Any) -> None:
        print(
            f"[{self.log_date_time_string()}] "
            f"{self.address_string()} "
            f"{format_string % args}"
        )


def scheduler_loop(stop_event: threading.Event) -> None:
    """Actualiza respuestas.json según el intervalo configurado."""
    while not stop_event.is_set():
        try:
            refresh_responses()
            print(f"[OK] respuestas.json actualizado: {utc_now()}")
        except Exception as error:  # Mantener vivo el servicio.
            print(f"[ERROR] Actualización: {error}", file=sys.stderr)

        config = load_json(CONFIG_PATH, {})
        hours = max(1, int(config.get("intervalo_actualizacion_horas", 6)))
        stop_event.wait(hours * 3600)


def run_server() -> None:
    """Inicia servidor y programador interno."""
    config = load_json(CONFIG_PATH, {})
    server_config = config.get("servidor", {})
    host = str(server_config.get("host", "127.0.0.1"))
    port = int(server_config.get("puerto", 8765))

    stop_event = threading.Event()
    scheduler = threading.Thread(
        target=scheduler_loop,
        args=(stop_event,),
        daemon=True,
        name="chongoku-scheduler",
    )
    scheduler.start()

    server = http.server.ThreadingHTTPServer(
        (host, port),
        ChongokuHandler,
    )

    print("============================================================")
    print(" CHONGOKU SMART WORLD AI - CEREBRO TEMPORAL")
    print("============================================================")
    print(f"Abre: http://{host}:{port}")
    print("Presiona Ctrl+C para cerrar.")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nCerrando sistema...")
    finally:
        stop_event.set()
        server.shutdown()
        server.server_close()


def run_daemon() -> None:
    """Mantiene el actualizador activo sin servidor web."""
    config = load_json(CONFIG_PATH, {})
    hours = max(1, int(config.get("intervalo_actualizacion_horas", 6)))

    print(f"Actualizador activo cada {hours} horas. Ctrl+C para cerrar.")
    try:
        while True:
            refresh_responses()
            print(f"[OK] Actualización completada: {utc_now()}")
            time.sleep(hours * 3600)
    except KeyboardInterrupt:
        print("\nActualizador detenido.")


def initialize_files() -> None:
    """Crea archivos vacíos necesarios."""
    SUMMARY_DIR.mkdir(parents=True, exist_ok=True)

    for path in (
        QUESTIONS_PATH,
        ANSWERS_PATH,
        INTERACTIONS_PATH,
        FEEDBACK_PATH,
    ):
        path.touch(exist_ok=True)

    if not KNOWLEDGE_PATH.exists():
        atomic_write_json(KNOWLEDGE_PATH, [])

    if not PUBLIC_RESPONSES_PATH.exists():
        refresh_responses()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Cerebro temporal de Chongoku Smart World AI."
    )
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--serve",
        action="store_true",
        help="Inicia el sitio y la API local.",
    )
    mode.add_argument(
        "--refresh",
        action="store_true",
        help="Actualiza respuestas.json una sola vez.",
    )
    mode.add_argument(
        "--daemon",
        action="store_true",
        help="Actualiza en segundo plano cada 6 horas.",
    )
    mode.add_argument(
        "--manual",
        metavar="PREGUNTA",
        help="Prueba una pregunta desde la terminal.",
    )

    arguments = parser.parse_args()
    initialize_files()

    if arguments.refresh:
        output = refresh_responses()
        print(json.dumps(output, ensure_ascii=False, indent=2))
        return 0

    if arguments.daemon:
        run_daemon()
        return 0

    if arguments.manual is not None:
        print(
            json.dumps(
                answer_question(arguments.manual),
                ensure_ascii=False,
                indent=2,
            )
        )
        return 0

    run_server()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
