﻿#requires -Version 5.1

$ErrorActionPreference = "Stop"

$Escritorio = [Environment]::GetFolderPath("Desktop")
$CarpetaHugoBoss = Join-Path $Escritorio "hugoboss"
$CarpetaPublic = Join-Path $CarpetaHugoBoss "public"
$CarpetaScripts = Join-Path $CarpetaHugoBoss "scripts"
$ArchivoZip = Join-Path $Escritorio "hugoboss.zip"
$Utf8SinBom = New-Object System.Text.UTF8Encoding($false)

if (Test-Path -LiteralPath $CarpetaHugoBoss) {
    Remove-Item -LiteralPath $CarpetaHugoBoss -Recurse -Force
}

if (Test-Path -LiteralPath $ArchivoZip) {
    Remove-Item -LiteralPath $ArchivoZip -Force
}

New-Item -ItemType Directory -Path $CarpetaHugoBoss -Force | Out-Null
New-Item -ItemType Directory -Path $CarpetaPublic -Force | Out-Null
New-Item -ItemType Directory -Path $CarpetaScripts -Force | Out-Null

$NetlifyToml = @'
[build]
  command = "bash scripts/install-hugo.sh && hugo"
  publish = "public"

[build.environment]
  HUGO_VERSION = "0.134.2"
'@

[System.IO.File]::WriteAllText(
    (Join-Path $CarpetaHugoBoss "netlify.toml"),
    $NetlifyToml,
    $Utf8SinBom
)

$IndexHtml = @'
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Hugo Boss - Chongoku Sebs Corp</title>
    <style>
        body { background: #0B0B0F; color: #0f0; font-family: monospace; display: flex; justify-content: center; align-items: center; height: 100vh; text-align: center; }
        h1 { font-size: 3rem; }
        .emoji { font-size: 5rem; }
    </style>
</head>
<body>
    <div>
        <div class="emoji">🍺</div>
        <h1>Hugo Boss está aquí</h1>
        <p>La nutria aprueba este build.</p>
        <p>🌴🌿🔥</p>
    </div>
</body>
</html>
'@

[System.IO.File]::WriteAllText(
    (Join-Path $CarpetaPublic "index.html"),
    $IndexHtml,
    $Utf8SinBom
)

$InstallHugo = @'
#!/bin/bash
if ! command -v hugo &> /dev/null; then
  echo "🔨 Instalando Hugo versión $HUGO_VERSION..."
  wget -q "https://github.com/gohugoio/hugo/releases/download/v${HUGO_VERSION}/hugo_${HUGO_VERSION}_Linux-64bit.tar.gz" -O /tmp/hugo.tar.gz
  tar -xzf /tmp/hugo.tar.gz -C /tmp
  mv /tmp/hugo /usr/local/bin/hugo
  chmod +x /usr/local/bin/hugo
else
  echo "✅ Hugo ya está instalado."
fi
'@

$InstallHugoLF = $InstallHugo -replace "`r`n", "`n"
$InstallHugoLF = $InstallHugoLF -replace "`r", "`n"

[System.IO.File]::WriteAllText(
    (Join-Path $CarpetaScripts "install-hugo.sh"),
    $InstallHugoLF,
    $Utf8SinBom
)

$Readme = @'
# Hugoboss.zip — Configuración para Netlify con Hugo
Este paquete permite que Netlify instale Hugo automáticamente durante el build y ejecute un comando que no rompa nada.

## Instrucciones
1. Sube el contenido de este ZIP a la raíz de tu repositorio en GitHub (o arrastra la carpeta a Netlify).
2. Netlify usará el `netlify.toml` y el script `install-hugo.sh` para instalar Hugo y ejecutar el build.
3. La página de prueba se generará en la carpeta `public/`.
4. Luego puedes reemplazar `public/index.html` con tu página real si quieres usar Hugo, o simplemente borrar la carpeta `public` y mantener tu HTML puro (pero entonces no necesitas Hugo).

## Para que la nutria esté feliz
- Si todo funciona, la nutria se toma una cheve.
- Si falla, la nutria se toma dos cheves y lo resuelve.
'@

[System.IO.File]::WriteAllText(
    (Join-Path $CarpetaHugoBoss "README.md"),
    $Readme,
    $Utf8SinBom
)

$Caguamas = @'
🍺 CAGUAMAS GANADAS POR HUGO BOSS

- Instalar Hugo en el build: 1 caguama.
- Configurar netlify.toml: 1 caguama.
- Crear script de instalación: 2 caguamas.
- Hacer que la nutria sonría: 3 caguamas (bonus).

Total: 7 caguamas 🍺🍺🍺🍺🍺🍺🍺
'@

[System.IO.File]::WriteAllText(
    (Join-Path $CarpetaHugoBoss "CAGUAMAS.txt"),
    $Caguamas,
    $Utf8SinBom
)

Compress-Archive `
    -LiteralPath $CarpetaHugoBoss `
    -DestinationPath $ArchivoZip `
    -CompressionLevel Optimal `
    -Force

Write-Host ""
Write-Host "============================================================" -ForegroundColor Magenta
Write-Host " ✅ HUGOBOSS.ZIP CREADO CORRECTAMENTE" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Magenta
Write-Host "Carpeta: $CarpetaHugoBoss" -ForegroundColor Cyan
Write-Host "ZIP:     $ArchivoZip" -ForegroundColor Yellow
Write-Host "🍺 La nutria aprueba este build." -ForegroundColor Green
