# Hugoboss.zip — Configuración para Netlify con Hugo
Este paquete permite que Netlify instale Hugo automáticamente durante el build y ejecute un comando que no rompa nada.

## Instrucciones
1. Sube el contenido de este ZIP a la raíz de tu repositorio en GitHub (o arrastra la carpeta a Netlify).
2. Netlify usará el `netlify.toml` y el script `install-hugo.sh` para instalar Hugo y ejecutar el build.
3. La página de prueba se generará en la carpeta `public/`.
4. Luego puedes reemplazar `public/index.html` con tu página real si quieres usar Hugo, o simplemente borrar la carpeta `public` y mantener tu HTML puro (pero entonces no necesitas Hugo).

## Para que la nutria esté feliz
- Si todo funciona, la nutria se toma una cheve.
- Si falla, la nutria se toma dos cheves y lo resuelve.
