#!/bin/bash
if ! command -v hugo &> /dev/null; then
  echo "🔨 Instalando Hugo versión $HUGO_VERSION..."
  wget -q "https://github.com/gohugoio/hugo/releases/download/v${HUGO_VERSION}/hugo_${HUGO_VERSION}_Linux-64bit.tar.gz" -O /tmp/hugo.tar.gz
  tar -xzf /tmp/hugo.tar.gz -C /tmp
  mv /tmp/hugo /usr/local/bin/hugo
  chmod +x /usr/local/bin/hugo
else
  echo "✅ Hugo ya está instalado."
fi
