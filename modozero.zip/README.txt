MODOZERO.ZIP — ZERO URF
========================
Incluye:
- index.html

Funciones:
- Modo Clásico y Viaje Interestelar.
- Bot ZERO URF.
- DeepSeek, OpenAI, Claude, Gemini, Mistral y Otros.
- Respuestas simuladas por modelo.
- Cuota de 10 mensajes diarios por dispositivo.
- Sanitización básica y alerta anti-prompt injection.
- Historial, modo y modelo guardados en localStorage.
- Reconocimiento de voz en Chrome y Edge.
- Panel de inversiones completamente simulado.
- Canvas con estrellas y estelas.

Uso:
1. Descomprime modozero.zip.
2. Sube index.html a la raíz del repositorio.
3. Reemplaza el archivo anterior.
4. Haz commit y Netlify desplegará la actualización.

Importante:
La seguridad del navegador es una primera capa. Una conexión real con APIs
requiere validación adicional en backend y nunca debe exponer claves en HTML.
