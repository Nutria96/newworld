# Chongoku Sebs Corp - Smart World AI

Paquete listo para desplegar en Netlify.

## Subir a GitHub

1. Descomprime `neworldupdate.zip`.
2. Abre el repositorio `Nutria96/newworld` en GitHub.
3. En la raíz del repositorio, reemplaza o sube todos estos archivos.
4. Confirma el commit en la rama que Netlify despliega, normalmente `main`.
5. Netlify detectará el commit y publicará automáticamente.

> No subas solamente el ZIP al repositorio: Netlify necesita los archivos descomprimidos en la raíz.

## Activar DeepSeek después

La interfaz funciona desde ahora en modo simulación. Para usar DeepSeek de forma real, crea una Netlify Function en `/.netlify/functions/deepseek` y guarda la API key como variable de entorno. Nunca pongas la API key dentro de `index.html`.

Después activa:

```html
<script>
window.SMART_WORLD_CONFIG = { live: true, endpoint: "/.netlify/functions/deepseek", model: "deepseek-chat" };
</script>
```

antes del script principal o cambia `live:false` a `live:true` cuando la función ya exista.
