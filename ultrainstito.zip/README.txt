ULTRAINSTITO.ZIP — CHONGOKU MULTIMODELO
========================================

Incluye:
- index.html

Esta es la versión multimodelo:
- DeepSeek
- OpenAI
- Claude
- Gemini
- Mistral
- Cuota diaria de 10 mensajes
- Historial local
- Entrada por voz
- Sanitización y alerta anti-inyección
- Panel de inversiones simulado
- Gráfico Canvas
- Fondo espacial, nebulosas y vehículos flotantes
- Diseño responsivo

Uso:
1. Descomprime ultrainstito.zip.
2. Sube index.html a la raíz de tu repositorio.
3. Reemplaza el index.html anterior.
4. Haz commit.
5. Netlify desplegará la actualización.
