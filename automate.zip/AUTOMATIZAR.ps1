﻿#requires -Version 5.1
<#
AUTOMATIZAR.ps1
Chongoku Sebs Corp - Smart World AI

Automatiza:
- Clonado o actualización del repositorio.
- Validación de archivos esenciales.
- Commit y push a GitHub.
- Despliegue automático por integración GitHub -> Netlify.
- Despliegue directo opcional con Netlify CLI.

No almacena contraseñas ni tokens.
GitHub y Netlify deben autenticarse con sus herramientas oficiales.
#>

[CmdletBinding()]
param(
    [switch]$ForceNetlifyDeploy,
    [switch]$NoBrowser,
    [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Step {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ConsoleColor]$Color = [ConsoleColor]::Cyan
    )
    Write-Host "`n▶ $Message" -ForegroundColor $Color
}

function Expand-ConfiguredPath {
    param([Parameter(Mandatory)][string]$PathValue)

    $expanded = [Environment]::ExpandEnvironmentVariables($PathValue)
    $expanded = $expanded.Replace('$env:USERPROFILE', $env:USERPROFILE)
    $expanded = $expanded.Replace('${env:USERPROFILE}', $env:USERPROFILE)
    return [System.IO.Path]::GetFullPath($expanded)
}

function Require-Command {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$InstallMessage
    )

    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "No se encontró '$Name'. $InstallMessage"
    }
}

function Invoke-External {
    param(
        [Parameter(Mandatory)][string]$Command,
        [Parameter()][string[]]$Arguments = @()
    )

    $printable = "$Command " + ($Arguments -join " ")
    Write-Host "  $printable" -ForegroundColor DarkGray

    if ($DryRun) {
        return
    }

    & $Command @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Falló el comando: $printable (código $LASTEXITCODE)"
    }
}

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$configPath = Join-Path $scriptRoot "config.json"

if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
    throw "No se encontró config.json junto a AUTOMATIZAR.ps1."
}

try {
    $config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
}
catch {
    throw "config.json no es válido: $($_.Exception.Message)"
}

$requiredConfig = @("repoURL", "branch", "carpetaLocal", "requiredFiles")
foreach ($property in $requiredConfig) {
    if (-not $config.PSObject.Properties.Name.Contains($property)) {
        throw "Falta la propiedad '$property' en config.json."
    }
}

$repoURL = [string]$config.repoURL
$branch = [string]$config.branch
$localFolder = Expand-ConfiguredPath ([string]$config.carpetaLocal)
$requiredFiles = @($config.requiredFiles)
$netlifySiteName = [string]$config.netlifySiteName
$netlifySiteId = [string]$config.netlifySiteId
$netlifyDeploysURL = [string]$config.netlifyDeploysURL
$publicURL = [string]$config.publicURL

Require-Command -Name "git" -InstallMessage "Instala Git para Windows desde su sitio oficial y vuelve a ejecutar el script."

Write-Host @"
============================================================
 CHONGOKU SEBS CORP - SMART WORLD AI
 Build & Deploy Agent
============================================================
Repositorio : $repoURL
Rama       : $branch
Carpeta    : $localFolder
Modo prueba: $DryRun
"@ -ForegroundColor Magenta

Write-Step "Preparando el repositorio"

$gitFolder = Join-Path $localFolder ".git"

if (Test-Path -LiteralPath $gitFolder -PathType Container) {
    Set-Location -LiteralPath $localFolder

    Invoke-External "git" @("remote", "set-url", "origin", $repoURL)
    Invoke-External "git" @("fetch", "origin", "--prune")
    Invoke-External "git" @("checkout", $branch)
    Invoke-External "git" @("pull", "--ff-only", "origin", $branch)
}
elseif (Test-Path -LiteralPath $localFolder) {
    throw "La carpeta '$localFolder' existe, pero no es un repositorio Git. Renómbrala, elimínala o cambia carpetaLocal en config.json."
}
else {
    $parentFolder = Split-Path -Parent $localFolder
    if (-not (Test-Path -LiteralPath $parentFolder)) {
        New-Item -ItemType Directory -Path $parentFolder -Force | Out-Null
    }

    Invoke-External "git" @("clone", "--branch", $branch, "--single-branch", $repoURL, $localFolder)
    Set-Location -LiteralPath $localFolder
}

Write-Step "Validando archivos esenciales"

$missing = @()
foreach ($relativeFile in $requiredFiles) {
    $fullPath = Join-Path $localFolder ([string]$relativeFile)
    if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
        $missing += [string]$relativeFile
    }
}

if ($missing.Count -gt 0) {
    throw "Faltan archivos obligatorios: $($missing -join ', '). Copia primero los archivos de la página dentro de '$localFolder'."
}

Write-Host "  Archivos esenciales encontrados." -ForegroundColor Green

Write-Step "Revisando cambios"

$status = if ($DryRun) { "DRY-RUN" } else { (& git status --porcelain) -join "`n" }

if ([string]::IsNullOrWhiteSpace($status)) {
    Write-Host "  No hay cambios locales para subir." -ForegroundColor Yellow
}
else {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $commitPrefix = if ($config.commitMessagePrefix) {
        [string]$config.commitMessagePrefix
    }
    else {
        "Actualización automática"
    }
    $commitMessage = "$commitPrefix - $timestamp"

    Write-Step "Creando commit"
    Invoke-External "git" @("add", "--all")
    Invoke-External "git" @("commit", "-m", $commitMessage)

    Write-Step "Subiendo cambios a GitHub"
    Invoke-External "git" @("push", "origin", $branch)

    Write-Host "  GitHub actualizado correctamente." -ForegroundColor Green
    Write-Host "  Netlify debe iniciar un despliegue automático por el push." -ForegroundColor Green
}

$shouldForceDeploy = $ForceNetlifyDeploy -or ($config.forceNetlifyDeployByDefault -eq $true)

if ($shouldForceDeploy) {
    Write-Step "Intentando despliegue directo con Netlify CLI"

    $netlify = Get-Command "netlify" -ErrorAction SilentlyContinue
    if (-not $netlify) {
        Write-Host "  Netlify CLI no está instalada. El push de GitHub seguirá activando el despliegue automático." -ForegroundColor Yellow
        Write-Host "  Para instalarla: npm install -g netlify-cli" -ForegroundColor DarkGray
    }
    else {
        $deployArgs = @("deploy", "--prod", "--dir", ".")

        if (-not [string]::IsNullOrWhiteSpace($netlifySiteId)) {
            $deployArgs += @("--site", $netlifySiteId)
        }
        elseif (-not [string]::IsNullOrWhiteSpace($netlifySiteName)) {
            Write-Host "  No hay netlifySiteId configurado; Netlify CLI usará el sitio vinculado localmente." -ForegroundColor Yellow
        }

        Invoke-External "netlify" $deployArgs
        Write-Host "  Despliegue directo completado." -ForegroundColor Green
    }
}

if (-not $NoBrowser -and -not [string]::IsNullOrWhiteSpace($netlifyDeploysURL)) {
    Write-Step "Abriendo el panel de despliegues"
    if (-not $DryRun) {
        Start-Process $netlifyDeploysURL
    }
}

Write-Host @"

============================================================
 ✅ PROCESO COMPLETADO
 GitHub : $repoURL
 Netlify: $publicURL
============================================================
"@ -ForegroundColor Green
