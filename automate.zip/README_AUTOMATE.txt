﻿AUTOMATE.ZIP — CHONGOKU SEBS CORP
=====================================

CONTENIDO
---------
- AUTOMATIZAR.ps1
- config.json
- README_AUTOMATE.txt

QUÉ HACE
--------
1. Clona el repositorio si todavía no existe.
2. Si ya existe, descarga los cambios de la rama main.
3. Comprueba que existan:
   - index.html
   - manifest.json
   - service-worker.js
4. Crea un commit solo cuando hay cambios.
5. Sube los cambios a GitHub.
6. Netlify inicia el despliegue automáticamente al detectar el push.
7. Abre el panel de despliegues de Netlify.

REQUISITOS
----------
- Windows PowerShell 5.1 o PowerShell 7.
- Git para Windows instalado.
- Sesión de GitHub autenticada mediante Git Credential Manager,
  GitHub CLI o una clave SSH.
- El sitio de Netlify conectado al repositorio de GitHub.
- Netlify CLI solamente es necesaria para usar -ForceNetlifyDeploy.

USO NORMAL
----------
1. Extrae automate.zip.
2. Conserva juntos AUTOMATIZAR.ps1 y config.json.
3. Revisa config.json.
4. Copia tus archivos web dentro de:
   %USERPROFILE%\Desktop\newworld
5. Abre PowerShell en la carpeta de automate.
6. Ejecuta:

   Set-ExecutionPolicy -Scope Process Bypass
   .\AUTOMATIZAR.ps1

PRUEBA SIN CAMBIAR NADA
-----------------------
   .\AUTOMATIZAR.ps1 -DryRun -NoBrowser

DESPLIEGUE DIRECTO OPCIONAL
---------------------------
Instala Node.js y después:

   npm install -g netlify-cli
   netlify login

Agrega el Site ID real en netlifySiteId dentro de config.json y ejecuta:

   .\AUTOMATIZAR.ps1 -ForceNetlifyDeploy

IMPORTANTE
----------
- El script no guarda contraseñas ni tokens.
- No pongas tokens de GitHub o Netlify dentro de config.json.
- Si la carpeta local existe pero no contiene .git, el script se detendrá
  para no borrar ni sobrescribir tus archivos.
- La URL con formato "agent-...--sebchongoku.netlify.app" suele ser una
  vista de despliegue. La URL principal configurada es:
  https://sebchongoku.netlify.app/
