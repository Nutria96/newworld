CHONGOKU SEBS CORP — NAVE PERDIDA
==================================

Contenido:
- index.html

Uso:
1. Descomprime el ZIP.
2. Sube index.html a la raíz de tu repositorio.
3. Reemplaza el index.html anterior.
4. Haz commit en GitHub.
5. Netlify desplegará la nueva versión automáticamente.

Funciones:
- Fondo espacial animado.
- Estrellas a velocidad luz.
- Vehículos hover flotantes.
- Orbe con modo viaje interestelar.
- Chat holográfico simulado.
- Reconocimiento de voz en Chrome y Edge.
- Diseño responsivo.
